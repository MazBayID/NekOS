# OK Partial

Skin NekOS. Panduan: docs/02_PANDUAN_MEMBUAT_SKIN.md di kit.

Validasi: `python3 -I tools/validate_skin.py <folder ini>`
Kemas: `python3 -I tools/pack_skin.py <folder ini>`
